-- 1.	Find the number of corona patients who faced shortness of breath.
SELECT COUNT(*) AS Number_Of_Patients
FROM sql_records
WHERE Corona = 'Positive' AND Shortness_of_breath = 'True';

-- 2.	Find the number of negative corona patients who have fever and sore_throat. 

SELECT COUNT(*) FROM sql_records WHERE Corona = 'negative' AND Fever = 'True' AND Sore_throat = 'True';

-- 3.	Group the data by month and rank the number of positive cases.
WITH Monthly_Positive_Cases_CTE AS (
    SELECT
        MONTH(Test_date) AS MONTH,
        COUNT(Corona) AS Positive_Cases
    FROM
        sql_records
    WHERE
        Corona = 'positive'
    GROUP BY
        MONTH(Test_date)
)

SELECT
    MONTH,
    Positive_Cases,
    RANK() OVER (ORDER BY Positive_Cases DESC) AS Rank_no
FROM
    Monthly_Positive_Cases_CTE
ORDER BY
    MONTH;

-- 4.	Find the female negative corona patients who faced cough and headache.
SELECT COUNT(*) FROM sql_records WHERE Corona = 'negative' AND Sex = 'female' AND Cough_symptoms = 'True' AND Headache = 'True';

-- 5.	How many elderly corona patients have faced breathing problems?
SELECT COUNT(*) FROM sql_records WHERE Corona = 'Positive' AND Age_60_above = 'Yes' AND Shortness_of_breath = 'True';


-- 6.	Which three symptoms were more common among COVID positive patients?
SELECT 
    CASE
        WHEN Cough_symptoms = 'True' THEN 'Cough_symptoms'
        WHEN Fever = 'True' THEN 'Fever'
        WHEN Sore_throat = 'True' THEN 'Sore_throat'
        WHEN Shortness_of_breath = 'True' THEN 'Shortness_of_breath'
        WHEN Headache = 'True' THEN 'Headache'
        ELSE 'No Symptom'
    END AS Symptom,
    COUNT(*) AS Count
FROM sql_records
WHERE Corona = 'positive'
GROUP BY Symptom
ORDER BY Count desc
LIMIT 3;


-- 7.	Which symptom was less common among COVID negative people?
SELECT 
    CASE
        WHEN Cough_symptoms = 'True' THEN 'Cough_symptoms'
        WHEN Fever = 'True' THEN 'Fever'
        WHEN Sore_throat = 'True' THEN 'Sore_throat'
        WHEN Shortness_of_breath = 'True' THEN 'Shortness_of_breath'
        WHEN Headache = 'True' THEN 'Headache'
        ELSE 'No Symptom'
    END AS Symptom,
    COUNT(*) AS Count
FROM sql_records
WHERE Corona = 'negative'
GROUP BY Symptom
ORDER BY Count ASC
LIMIT 1;


-- 8.	What are the most common symptoms among COVID positive males whose known contact was abroad?
SELECT
    CASE
        WHEN Cough_symptoms = 'True' THEN 'Cough_symptoms'
        WHEN Fever = 'True' THEN 'Fever'
        WHEN Headache = 'True' THEN 'Headache'
        ELSE 'Other Symptoms'
    END AS Symptom,
    COUNT(*) AS Count
FROM sql_records
WHERE Corona = 'positive' AND Sex = 'male' AND Known_contact = 'Abroad'
GROUP BY Symptom
ORDER BY Count DESC
LIMIT 3;

 


